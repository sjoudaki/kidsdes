#!/bin/bash -l

#SBATCH -A dirac-project
#SBATCH -p cosma7
#SBATCH --nodes 4
#SBATCH --tasks-per-node=1
#SBATCH -o standard_output_file.%J.out
#SBATCH -e standard_error_file.%J.err
#SBATCH -t 72:00:00
#SBATCH -J job_name
#SBATCH --exclusive
#SBATCH --mail-type=END                          # notifications for job done & fail
#SBATCH --mail-user=<email address>

#  The above runs a job on 4 nodes, with each node only executing a single
#  rank, so you have 28 or 16 threads per node depending on the compute nodes.

module purge
#load the modules used to build your program.
module load intel_comp
module load intel_mpi
module load hdf5

# Run the program
mpirun -np $SLURM_NTASKS your_program your_inputs


