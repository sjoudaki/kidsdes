#!/bin/bash -l

#SBATCH -A dp016
#SBATCH -p cosma7
#SBATCH --nodes 4
#SBATCH --tasks-per-node=2
##SBATCH -o standard_output_file.%J.out
##SBATCH -e standard_error_file.%J.err
#SBATCH -t 72:00:00
#SBATCH -J cosmomc
#SBATCH --exclusive
##SBATCH --mail-type=END                          # notifications for job done & fail
##SBATCH --mail-user=<email address>

cd $SLURM_SUBMIT_DIR

echo $SLURM_JOB_ID > testpbskv450desy1.txt

mpirun --map-by node --bind-to none -np 8 -x OMP_NUM_THREADS=14 ./cosmomc testkv450desy1.ini >> testpbskv450desy1.txt
