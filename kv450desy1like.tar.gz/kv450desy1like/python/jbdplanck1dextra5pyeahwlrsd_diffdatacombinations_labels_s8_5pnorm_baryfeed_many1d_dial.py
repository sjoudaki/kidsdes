import planckStyle
#g = planckStyle.getSinglePlotter(chain_dir = '../chains/')
#g = planckStyle.getSubplotPlotter(width_inch=5,chain_dir = '../chains/')
g = planckStyle.getSubplotPlotter(subplot_size=2,chain_dir = '../chains/')
#g.settings.rcSizes(9.5,12.0,7.0)
###################################g.settings.rcSizes(8.0,9.0,8.0)
#g.settings.rcSizes(6.5,9.5,10.0)
g.settings.rcSizes(8.0,9.0,8.0)
#roots=['BD_CS_PLANCK_NOBAR_planckonlyigen','BD_CS_correctgrowth_withbossandplanckandjla_correctgrowth_onlyplanckwithpantheon','BD_CS_correctgrowth_withbossandplanckandjla_correctgrowth_nokids2dflens','BD_CS_PLANCK_TTTEB_CMBNONLINEARLENSED_correctgrowth_withbaosncmb_correct']
#roots=['BD_CS_PLANCK_NOBAR_planckonlyigen','BD_CS_correctgrowth_withbossandplanckandjla_correctgrowth_onlyplanckwithpantheon','BD_CS_correctgrowth_withbossandplanck_correctgrowth_nokids2dflens','BD_CS_PLANCK_TTTEB_CMBNONLINEARLENSED_correctgrowth_withbaosncmb_correct']
#roots=['BD_CS_PLANCK_NOBAR_planckonlyigen','BD_CS_correctgrowth_withbossandplanckandjla_correctgrowth_onlyplanckwithpantheon','BD_CS_correctgrowth_withbossandplanck_correctgrowth_nokids2dflens','BD_PLANCK_TTTEB_ACT_CMBNONLINEARLENSED_igencorrect','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_withtauprior_no3x2pt_nocmblensing_fix1geff_notauprior_noneutrinos']
#########roots=['BD_CS_PLANCK_NOBAR_planckonlyigen','BD_CS_correctgrowth_withbossandplanckandjla_correctgrowth_onlyplanckwithpantheon','BD_CS_correctgrowth_withbossandplanck_correctgrowth_nokids2dflens','BD_PLANCK_TTTEB_ACT_CMBNONLINEARLENSED_igencorrect','BD_LENSING_RSD_correctgrowthigen2v']
#############roots=['BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_ss3','BD_PLANCK_TTTEB_CMBNONLINEARLENSED_igennotheta_correct_varygeff_igen','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_withtauprior_no3x2pt_nocmblensing_notauprior_noneutrinos','']
#roots=['BD_PLANCK_TTTEB_CMBNONLINEARLENSED_LENSINGRSD_NU_correctgrowth_noplanck','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_fix1geff_noplanck','BD_CS_PLANCK_NU_NOBAR_correctgrowth_planckonly','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_withtauprior_no3x2pt_nocmblensing_fix1geff_notauprior_withteb','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_fix1geff','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata']
#samples = g.sampleAnalyser.samplesForRoot('BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noplanck')
#p = samples.getParams()
#s8omegamp5norm=p.s8omegamp5/(0.3**0.5)
#samples.addDerived(s8omegamp5norm, name='s8omegamp5norm', label='S_8')
#samples.updateBaseStatistics()
#samples = g.sampleAnalyser.samplesForRoot('BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noneutrinos_noplanck_lcdmlimit')
#p = samples.getParams()
#s8omegamp5norm=p.s8omegamp5/(0.3**0.5)
#samples.addDerived(s8omegamp5norm, name='s8omegamp5norm', label='S_8')
#samples.updateBaseStatistics()
#samples = g.sampleAnalyser.samplesForRoot('BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_withtauprior_no3x2pt_nocmblensing_notauprior_halofit')
#p = samples.getParams()
#s8omegamp5norm=p.s8omegamp5/(0.3**0.5)
#samples.addDerived(s8omegamp5norm, name='s8omegamp5norm', label='S_8')
#samples.updateBaseStatistics()
#samples = g.sampleAnalyser.samplesForRoot('BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_withtauprior_no3x2pt_nocmblensing_lcdmlimit_notauprior_noneutrinos_withteb')
#p = samples.getParams()
#s8omegamp5norm=p.s8omegamp5/(0.3**0.5)
#samples.addDerived(s8omegamp5norm, name='s8omegamp5norm', label='S_8')
#samples.updateBaseStatistics()
#samples = g.sampleAnalyser.samplesForRoot('BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata')
#p = samples.getParams()
#s8omegamp5norm=p.s8omegamp5/(0.3**0.5)
#samples.addDerived(s8omegamp5norm, name='s8omegamp5norm', label='S_8')
#samples.updateBaseStatistics()
####################################3roots=['BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noplanck','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noneutrinos_noplanck_lcdmlimit','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_withtauprior_no3x2pt_nocmblensing_notauprior_halofit','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_withtauprior_no3x2pt_nocmblensing_lcdmlimit_notauprior_noneutrinos_withteb', 'BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata']
#roots=['BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noplanck','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noneutrinos_noplanck_lcdmlimit','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata']
roots=['BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noplanck','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noneutrinos_noplanck_lcdmlimit','BD_CS_correctgrowth_ss4igen_bootstrap_varygeff_withneutrinos_withplanckandbossextradata_noplanck']
params = g.get_param_array(roots[0], ['ampia','baryfeed'])
#g.plot_1d(roots,'s8omegamp5norm',colors=['#40E0D0','#FF2500','#8B4513','#1E90FF'],normalized=True,ls=['--','--','-.','-.'],lws=[1.5,1.5,1.5,1.5])
##########g.make_figure(nplot=1,xstretch=2.6)
#g.make_figure(nplot=1,xstretch=1.0)
############################################################g.make_figure(nplot=1,xstretch=2.8)
###40E0D0
###FF2500
#####g.plot_1d(roots,'EFTwbds',colors=['#40E0D0','#FF2500','#FF8000','#000000','#DA3287','#1E90FF'],normalized=True,ls=['-','--','-.',':','-','--'],lws=[1.3,1.3,1.3,1.3,1.3,1.3])
###########g.plot_1d(roots,'s8omegamp5',colors=['#0e5c14','#00588b','#DA3287','#131324','#8B4513','#1E90FF'],normalized=True,ls=['-','--','-.',':','-','--'],lws=[1.3,1.3,1.3,1.3,1.3,1.3])
########################g.plot_1d(roots,'s8omegamp5norm',colors=['#0e5c14','#DA3287','#8B4513','#1E90FF','#000000'],normalized=True,ls=['--',':','--',':','-'],lws=[1.3,1.3,1.3,1.3,1.3])
##g.plot_1d(roots,'s8omegamp5norm',colors=['#0e5c14','#88a60f','#00588b','#FF8000','#000000'],normalized=True,ls=['--','--',':',':','-'],lws=[1.3,1.3,1.3,1.3,1.3])
############################################33g.plot_1d(roots,'baryfeed',colors=['#0e5c14','#88a60f','#00588b','#FF8000','#000000'],normalized=True,ls=['--',':','--',':','-'],lws=[1.3,1.3,1.3,1.3,1.3])
#g.plots_1d(roots,['ampia','baryfeed'],nx=2,colors=['#0e5c14','#88a60f','#000000'],normalized=True,lws=[1.3,1.3,1.3],legend_labels=['KiDS$\\times$2dFLenS + All-BOSS + Pantheon (JBD+$G_{\\mathrm{matter}}+\sum m_{\\nu}$)','KiDS$\\times$2dFLenS + All-BOSS + Pantheon ($\\Lambda$CDM)','KiDS$\\times$2dFLenS + All-BOSS + All-Planck + Pantheon (JBD+$G_{\\mathrm{matter}}$+$\sum m_{\\nu}$)'],ls=['--',':','-'],legend_loc='upper right',label_order=[0,1,2])
g.plots_1d(roots,['ampia','baryfeed'],colors=['#0e5c14','#88a60f','#000000'],nx=2,normalized=True,lws=[1.3,1.3,1.3],legend_labels=['1','2','3'],ls=['--',':','-'],legend_loc='upper right',label_order=[0,1,2])
#g.add_legend(['Planck (JBD)','Planck+Pantheon (JBD)','Planck+BOSS (JBD)','Planck+ACT','Plancklens+BOSS+SNe+WL/RSD (JBD+$G_{\mathrm{matter}}$)'], legend_loc='upper left',label_order=[0,1,2,3,4],align_right=False,fontsize=9,line_offset='-0.5');
#####g.add_legend(['Planck (JBD)','Planck+Pantheon (JBD)','Planck+BOSS (JBD)','Planck+ACT (JBD)','KiDS 3$\\times$2pt (JBD)'], legend_loc='lower left',label_order=[0,1,2,3,4],align_right=False,fontsize=9,line_offset='-0.5');
#g.add_legend(['Planck (JBD)','Planck+Pantheon (JBD)','Planck+BOSS (JBD)','Planck+ACT (JBD)','KiDS$\\times$\{2dFLenS+BOSS\} (JBD)'], legend_loc='lower left',label_order=[0,1,2,3,4],align_right=False,fontsize=8,line_offset='-0.5');
#################g.add_legend(['KiDS$\\times$\{2dFLenS+BOSS\}','KiDS$\\times$2dFLenS + All-BOSS + Pantheon','Planck','Planck + All-BOSS + Pantheon','KiDS$\\times$2dFLenS + All-BOSS + All-Planck + Pantheon','KiDS$\\times$2dFLenS + All-BOSS + All-Planck + Pantheon (incl.$G_{\\mathrm{matter}}$)'], legend_loc='lower left',label_order=[2,0,3,1,4,5],align_right=False,fontsize=5.4);
#g.add_legend(['KiDS$\\times$\{2dFLenS+BOSS\}','KiDS$\\times$2dFLenS + All-BOSS + Pantheon','Planck','Planck + All-BOSS + Pantheon','KiDS$\\times$2dFLenS + All-BOSS + All-Planck + Pantheon','KiDS$\\times$2dFLenS + All-BOSS + All-Planck + Pantheon (incl.$G_{\\mathrm{matter}}$)'], legend_loc='upper left',label_order=[2,0,3,1,4,5],align_right=False,fontsize=5.6);
#############################################################g.add_legend(['KiDS$\\times$2dFLenS + All-BOSS + Pantheon (JBD+$G_{\\mathrm{matter}}+\sum m_{\\nu}$)','KiDS$\\times$2dFLenS + All-BOSS + Pantheon ($\\Lambda$CDM)','Planck + All-BOSS + Pantheon (JBD+$G_{\\mathrm{matter}}$+$\sum m_{\\nu}$)','Planck + All-BOSS + Pantheon ($\\Lambda$CDM)','KiDS$\\times$2dFLenS + All-BOSS + All-Planck + Pantheon (JBD+$G_{\\mathrm{matter}}$+$\sum m_{\\nu}$)'], legend_loc='upper left',label_order=[4,0,2,1,3],align_right=False,fontsize=4.9);
#####g.add_legend(['Planck (fix $G_\mathrm{matter},\sum m_{\\nu}$)','Planck+Pantheon','Planck+BOSS','Planck+ACT','KiDS$\\times$(2dFLenS+BOSS)'], legend_loc='lower left',label_order=[0,1,2,3,4],align_right=False,fontsize=9,line_offset='-0.5');
#g.add_legend(['Planck (JBD)','Planck+Pantheon','Planck+BOSS','Planck+ACT','KiDS$\\times$(2dFLenS+BOSS)'], legend_loc='lower left',label_order=[0,1,2,3,4],align_right=False,fontsize=9,line_offset='-0.5');
g.settings.colored_text=True
#g.setAxes(params, lims=[55,90,0,0.75])
#g.setAxes(params, lims=[55,90,0,0.15])
g.add_x_marker(3.13)
g.export('jbdplanck1dextra5pyeahwlrsd_diffdatacombinations_labels_s8_5pnorm_baryfeed_many1d_dial.pdf')
